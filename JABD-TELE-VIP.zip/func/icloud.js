function config(){
    return{
        "name": "icloud",
        "main": "icloud.js",
        "commandMap": {
            "icloud": {
                "more": "",
                "des": "ID Apple By Gon",
                "func": "icloud"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "MonaLisa",
        "version": "0.0.1"
    }
}

async function icloud(ctx){
    var axios = require("axios");
    try {
    var {data} = await axios.get('https://justgon-dev.site/spot')
    if(data.resultout[0].status == '{}') {
      ctx.reply(`┏━━━━━━━━━━━━━━━━━━\n┠⌬ 𝐄𝐦𝐚𝐢𝐥 : vip01spcsa@gmail.com\n┠⌬ 𝐏𝐚𝐬𝐬 : CSA-4gvpn.Tk\n┠⌬ Lưu ý 1 : 🦋 𝙆𝙝𝒐̂𝙣𝙜 𝙡𝙤𝙜𝙞𝙣 𝙄𝙘𝙡𝙤𝙪𝙙, 𝙘𝙝𝒊̉ đ𝒖̛𝒐̛̣𝙘 𝙡𝙤𝙜𝙞𝙣 𝙩𝙧𝙤𝙣𝙜 𝘼𝙥𝙥𝙨𝙩𝙤𝙧𝙚. 𝙉𝒆̂́𝙪 𝙡𝙤𝙜 𝙄𝙘𝙡𝙤𝙪𝙙 𝙩𝙝𝒊̀ 𝙨𝒆̃ 𝙥𝙝𝒂̉𝙞 𝙘𝒐́ 𝙥𝙝𝒊́ 𝙢𝒐̛̉. 𝘽𝒂́𝙤 𝙩𝙧𝒖̛𝒐̛́𝙘 𝙠𝙝𝒐̂𝙣𝙜 𝙡𝒂̣𝙞 𝙗𝒂̉𝙤 𝙡𝒐̛̣𝙞 𝙙𝒖̣𝙣𝙜...🦋\n┠⌬ Lưu ý 2 : Khi gặp xác minh tài khoản (Đọc thật kĩ: ID yêu cầu cài bảo mật) thì chọn dòng "Các Tùy Chọn Khác", sau đó chọn "Không nâng cấp" là được 🇻🇳\n**Độc Chiếm Đéo Được Đâu Vì Acc Đéo Có CC Gì Cả. Toàn Máy Xịn Mà Lòng Tham Vô Đáy...**\n┠⌬ 〄  𝐁𝐎𝐓 𝐁𝐘 : @Lisa_is_me [ 𝐀𝐝𝐦𝐢𝐧 ] \n┗━━━━━━━━━━━━━━━━━━ `)
    } else {
      ctx.reply(`┏━━━━━━━━━━━━━━━━━━\n┠⌬ 𝐄𝐦𝐚𝐢𝐥 : vip01spcsa@gmail.com\n┠⌬ 𝐏𝐚𝐬𝐬 : CSA-4gvpn.TK\n┠⌬ Lưu ý 1 : 🦋 Không login Icloud, chỉ được login trong Appstore. Nếu log Icloud thì sẽ phải có phí mở. Báo trước không lại bảo lợi dụng... 🦋\n┠⌬ Lưu ý 2 : Khi gặp xác minh tài khoản (Đọc thật kĩ: ID yêu cầu cài bảo mật) thì chọn dòng "Các Tùy Chọn Khác", sau đó chọn "Không nâng cấp" là được 🇻🇳\n**Độc Chiếm Đéo Được Đâu Vì Acc Đéo Có CC Gì Cả. Toàn Máy Xịn Mà Lòng Tham Vô Đáy...**\n┠⌬ 〄  𝐁𝐎𝐓 𝐁𝐘 : @Lisa_is_me [ 𝐀𝐝𝐦𝐢𝐧 ] \n┗━━━━━━━━━━━━━━━━━━ `)
    }
    } catch(err) {
        ctx.reply(err);
    }
    }

module.exports = {
    icloud,
    config
};