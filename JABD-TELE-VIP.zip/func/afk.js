function config(){
    return{
        "name": "afk",
        "main": "afk.js",
        "commandMap": {
            "afk": {
                "more": "",
                "des": "",
                "func": "afk"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "Lisa",
        "version": "0.0.1"
    }
}

async function afk(ctx){
   var options = {
      reply_markup: JSON.stringify({
        inline_keyboard: [
          [{ text: 'Some button text 1', callback_data: '1' }],
          [{ text: 'Some button text 2', callback_data: '2' }],
          [{ text: 'Some button text 3', callback_data: '3' }]
        ]
      })
    };
bot.sendMessage(msg.chat.id, "answer.", option);

module.exports = {
    afk,
    config
};