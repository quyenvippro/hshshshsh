function config(){
    return{
        "name": "gai",
        "main": "gai.js",
        "commandMap": {
            "gai": {
                "more": "",
                "des": "Request ảnh gai đẹp =)",
                "func": "gai"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "Lisa",
        "version": "0.0.1"
    }
}

async function gai(ctx){
    var axios = require("axios");
    try {
    ctx.replyWithPhoto({
        url: (await axios('https://api.ditlolichapfbi.tk/image?type=gai&apikey=phongdeptraiprovip')).data.data,
    })
    } catch(err) {
        ctx.reply(err);
    }
    }

module.exports = {
    gai,
    config
};