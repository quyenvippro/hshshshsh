function config(){
    return{
        "name": "trai",
        "main": "trai.js",
        "commandMap": {
            "trai": {
                "more": "",
                "des": "Request ảnh trai đẹp =)",
                "func": "trai"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "Lisa",
        "version": "0.0.1"
    }
}

async function trai(ctx){
    var axios = require("axios");
    try {
    ctx.replyWithPhoto({
        url: (await axios('https://api.vodaybubuoi.tk/trai.php/')).data.data,
    })
    } catch(err) {
        ctx.reply(err);
    }
    }

module.exports = {
    trai,
    config
};