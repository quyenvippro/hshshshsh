function config(){
    return{
        "name": "id",
        "main": "id.js",
        "commandMap": {
            "id": {
                "more": "",
                "des": "",
                "func": "id"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "JustGon",
        "version": "0.0.1"
    }
}

async function id(ctx){
    ctx.replyWithMarkdown(`↾჻ 👥*Chat ID : * : ${ctx.message.chat.id}\n↾჻ 🙋‍♂️ *User ID* : ${(ctx.message.from.id)}\n↾჻ 💁‍♀️ *Check By* : *@${ctx.message.from.username}*\n↾჻ 👩‍💻*Bot By* : *@lisa_is_me*`)
    }

module.exports = {
    id,
    config
};