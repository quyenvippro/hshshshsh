function config(){
    return{
        "name": "netflix",
        "main": "netflix.js",
        "commandMap": {
            "netflix": {
                "more": "",
                "des": "TK Netflix by Yui",
                "func": "netflix"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "Lisa",
        "version": "0.0.1"
    }
}

async function netflix(ctx){
    var axios = require("axios");
    try {
    var {data} = await axios.get('https://justgon-dev.site/spot')
    if(data.resultout[0].status == 'access') {
      ctx.reply(`┏━━━━━━━━━━━━━━━━━━\n┠⌬ 𝐄𝐦𝐚𝐢𝐥 : netflixhehe01@cutradition.com ✨\n┠⌬ 𝐏𝐚𝐬𝐬 : 666666 💗\n┠⌬ 🌈 Xem chill đừng quậy nữa :<🦋\n┠⌬ Lưu ý 2 :💎 Mua VIP để xài lệnh check cê gửi BOT <3\n┠⌬ 〄  𝐁𝐎𝐓 𝐁𝐘 : @Lisa_is_me [ 𝐀𝐝𝐦𝐢𝐧 ] \n┗━━━━━━━━━━━━━━━━━━ `)
    } else {
      ctx.reply(`┏━━━━━━━━━━━━━━━━━━\n┠⌬ 𝐄𝐦𝐚𝐢𝐥 : netflixhehe01@cutradition.com ✨\n┠⌬ 𝐏𝐚𝐬𝐬 : 666666 💗\n┠⌬ 🌈 Xem chill đừng quậy nữa :<🦋\n┠⌬ Lưu ý 2 :💎 Mua VIP để xài lệnh check cê gửi BOT <3\n┠⌬ 〄  𝐁𝐎𝐓 𝐁𝐘 : @Lisa_is_me [ 𝐀𝐝𝐦𝐢𝐧 ] \n┗━━━━━━━━━━━━━━━━━━ `)
    }
    } catch({}) {
        ctx.reply(err);
    }
    }

module.exports = {
    netflix,
    config
};