function config(){
    return{
        "name": "hentai",
        "main": "henta.js",
        "commandMap": {
            "henta": {
                "more": "",
                "des": "Request ảnh henta đẹp =)",
                "func": "henta"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "Lisa",
        "version": "0.0.1"
    }
}

async function henta(ctx){
    var axios = require("axios");
    try {
    ctx.replyWithPhoto({
        url: (await axios('https://api.ditlolichapfbi.tk/image?type=hentai&apikey=phongdeptraiprovip')).data.data,
    })
    } catch(err) {
        ctx.reply(err);
    }
    }

module.exports = {
    henta,
    config
};