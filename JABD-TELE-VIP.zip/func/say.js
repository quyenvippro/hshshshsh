function config(){
    return{
        "name": "say",
        "main": "say.js",
        "commandMap": {
            "say": {
                "more": "",
                "des": "",
                "func": "say"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "Lisa",
        "version": "0.0.1"
    }
}

async function text(ctx){
    ctx.replyWithMarkdown(`↾჻ ${ctx.message.time}\n↾჻ 👩‍💻*Bot By* : *@lisa_is_me*`)
    }

module.exports = {
    text,
    config
};