function config(){
    return{
        "name": "nude2",
        "main": "nude2.js",
        "commandMap": {
            "nude2": {
                "nude2": "",
                "des": "Request ảnh nude",
                "func": "nude2"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "Lisa",
        "version": "0.0.1"
    }
}

async function nude2(ctx){
    var axios = require("axios");
    try {
    ctx.replyWithPhoto({
        url: (await axios('https://api-milo.herokuapp.com/nude')).data.url,
    })
    } catch(err) {
        ctx.reply(err);
    }
    }

module.exports = {
    nude2,
    config
};