function config(){
    return{
        "name": "spotgen",
        "main": "spotgen.js",
        "commandMap": {
            "spotgen": {
                "more": "",
                "des": "Gen spotify account",
                "func": "spotgen"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "JustGon",
        "version": "0.0.1"
    }
}

async function spotgen(ctx){
    var axios = require("axios");
    try {
    var {data} = await axios.get('https://justgon-dev.site/spot')
    if(data.resultout[0].status == 'success') {
      ctx.replyWithMarkdown(`┏━━━━━━━━━━━━━━━━━━\n┠⌬          🔅[𝑺𝒑𝒐𝒕𝒊𝒇𝒚 𝑨𝒄𝒄]🔅\n┠⌬  ✅ 𝚂𝚞𝚌𝚌𝚎𝚜𝚜 ✅\n┠⌬ 𝐄𝐦𝐚𝐢𝐥 : ${data.resultout[0].email}\n┠⌬ 𝐏𝐚𝐬𝐬 : ${data.resultout[0].password}\n┠⌬ 𝗧𝘆𝗽𝗲 : 🦋 𝐅𝐫𝐞𝐞 🦋\n┠⌬ 𝐂𝐨𝐮𝐧𝐭𝐫𝐲 : VN 🇻🇳\n┠⌬ Year : ${data.resultout[0].birth_year}\n┠⌬ 𝗖𝗵𝗲𝗰𝗸 𝗕𝘆 : *@${ctx.message.from.username}*\n┠⌬ 〄  𝐁𝐎𝐓 𝐁𝐘 : *@Lisa_is_me* [ 𝐀𝐝𝐦𝐢𝐧 ] \n┗━━━━━━━━━━━━━━━━━━ `)
    } else {
      ctx.reply(`┏━━━━━━━━━━━━━━━━━━\n┠⌬          🔅[𝑺𝒑𝒐𝒕𝒊𝒇𝒚 𝑨𝒄𝒄]🔅\n┠⌬  ❌ 𝙵𝚊𝚒𝚕𝚎𝚍 ❌\n┠⌬ 𝐄𝐦𝐚𝐢𝐥 : ${data.resultout[0].email}\n┠⌬ 𝐏𝐚𝐬𝐬 : ${data.resultout[0].password}\n┠⌬ 𝗧𝘆𝗽𝗲 : 🦋 𝐅𝐫𝐞𝐞 🦋\n┠⌬ 𝐂𝐨𝐮𝐧𝐭𝐫𝐲 : VN 🇻🇳\n┠⌬ Year : ${data.resultout[0].birth_year}\n┠⌬ 〄  𝐁𝐎𝐓 𝐁𝐘 : @Lisa_is_me [ 𝐀𝐝𝐦𝐢𝐧 ] \n┗━━━━━━━━━━━━━━━━━━ `)
    } 
    } catch(err) {
        ctx.reply(err);
    }
    }

module.exports = {
    spotgen,
    config
};