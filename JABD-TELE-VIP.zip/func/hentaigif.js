function config(){
    return{
        "name": "hentaigif",
        "main": "hentaigif.js",
        "commandMap": {
            "hentaigif": {
                "more": "",
                "des": "Request hentaigif đẹp =)",
                "func": "hentaigif"
            }
        },
        "nodeDepends":{
            "axios" : ""
        },
        "author": "Lisa",
        "version": "0.0.1"
    }
}

async function hentaigif(ctx){
    var axios = require("axios");
    try {
    ctx.replyWithPhoto({
        url: (await axios('https://api.vodaybubuoi.tk/nude.php/')).data.data,
    })
    } catch(err) {
        ctx.reply(err);
    }
    }

module.exports = {
    hentaigif,
    config
};