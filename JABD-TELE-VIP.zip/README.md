# JABD-Bot
# How To Use
1. Step for the beginners who have never installed bots before (if you have tried other source bots, please see item 2)
- Step 1 : Double Click On NodeGitInstall.bat
- Step 2 : Double Click On wibuildtools.bat
2. Setup And Run Bot
- Step 1 : Double Click On setup.bat or you can
  ```sh
  npm install
  ```
- Step 2 : Double Click On startbot.bat
  or you can
  ```sh
  npm start
  ```
- Step 3 : ShutDown Bot, then get bot token and push it into bot config
- Step 4 : Double Click On startbot.bat again
  or you can
  ```sh
  npm start
  ```
 <h3>And We Are Done. Enjoy It!</h3>
